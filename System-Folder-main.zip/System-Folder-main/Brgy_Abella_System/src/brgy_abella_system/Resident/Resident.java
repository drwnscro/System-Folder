
package brgy_abella_system.Resident;

import brgy_abella_system.Resident.*;
import java.time.LocalDate;
import javafx.scene.control.Button;

public class Resident {
    private String id,firstName,middleName,lastName,houseNo,Street,Barangay,City,Province, Gender, maritalStatus, Citizenship, Occupation, DOB;
    private int Access;

    public Resident(String id, String firstName, String middleName, String lastName, String houseNo, String Street, String Barangay, String City, String Province, String Gender, String maritalStatus, String Citizenship, String Occupation, String DOB) {
        this.id = id;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.houseNo = houseNo;
        this.Street = Street;
        this.Barangay = Barangay;
        this.City = City;
        this.Province = Province;
        this.Gender = Gender;
        this.maritalStatus = maritalStatus;
        this.Citizenship = Citizenship;
        this.Occupation = Occupation;
        this.DOB = DOB;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String gethouseNo() {
        return houseNo;
    }

    public void sethouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getStreet() {
        return Street;
    }

    public void setStreet(String Street) {
        this.Street = Street;
    }

    public String getBarangay() {
        return Barangay;
    }

    public void setBarangay(String Barangay) {
        this.Barangay = Barangay;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getProvince() {
        return Province;
    }

    public void setProvince(String Province) {
        this.Province = Province;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }
    
    public String getmaritalStatus() {
        return maritalStatus;
    }

    public void setmaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }
    
    public String getCitizenship() {
        return Citizenship;
    }

    public void setCitizenship(String Citizenship) {
        this.Citizenship = Citizenship;
    }
    
    public String getOccupation() {
        return Occupation;
    }

    public void setOccupation(String Occupation) {
        this.Occupation = Occupation;
    }
    
    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }
}
