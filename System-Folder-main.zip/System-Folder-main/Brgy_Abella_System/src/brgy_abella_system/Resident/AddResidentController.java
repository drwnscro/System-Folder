/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package brgy_abella_system.Resident;

import brgy_abella_system.Resident.*;
import brgy_abella_system.Functions;
import brgy_abella_system.Repeatables;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author xande
 */
public class AddResidentController implements Initializable 
{
    Repeatables action = new Repeatables();
    Functions AddResidentMode1 = new Functions();
    ObservableList<String> Gender = FXCollections.observableArrayList("Male", "Female");
    ObservableList<String> MaritalStatus = FXCollections.observableArrayList("Single", "Married", "Widow");
    @FXML
    private TextField Res_First_Name;
    @FXML
    private TextField Res_Middle_Name;
    @FXML
    private TextField Res_Last_Name;
    @FXML
    private TextField Res_House_No;
    @FXML
    private TextField Res_Street;
    @FXML
    private TextField Res_Barangay;
    @FXML
    private TextField Res_City;
    @FXML
    private TextField Res_Province;
    @FXML
    private ComboBox<String> Res_Gender;
    @FXML
    private ComboBox<String> Res_Marital_Status;
    @FXML
    private TextField Res_Citizenship;
    @FXML
    private TextField Res_Occupation;
    @FXML
    private DatePicker Res_Birth_Date;
    @FXML
    private Button cancelBtn;
    @FXML
    private Label Alert;
    @FXML
    private TextField Emp_id;
    @FXML
    private Button saveBtn;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Res_Gender.setItems(Gender);
        Res_Marital_Status.setItems(MaritalStatus);
    }

    @FXML
    public void ExitButtonAction(ActionEvent event) {
        action.Exit(cancelBtn);
    }

    @FXML
    public void SaveButtonAction(ActionEvent event) throws SQLException, IOException {
        String fname = Res_First_Name.getText().toUpperCase();
        String mname = Res_Middle_Name.getText().toUpperCase();
        String lname = Res_Last_Name.getText().toUpperCase();
        String id = Emp_id.getText().toUpperCase();
        String houseno = Res_House_No.getText().toUpperCase();
        String street = Res_Street.getText().toUpperCase();
        String barangay = Res_Barangay.getText().toUpperCase();
        String city = Res_City.getText().toUpperCase();
        String prov = Res_Province.getText().toUpperCase();
        String citizenship = Res_Citizenship.getText().toUpperCase();
        String occupation = Res_Occupation.getText().toUpperCase();
        LocalDate DOB = Res_Birth_Date.getValue();
        String gender = Res_Gender.getValue().toUpperCase();
        String mstatus = Res_Marital_Status.getValue().toUpperCase();
        if (!fname.isEmpty() && !lname.isEmpty() && !id.isEmpty() && DOB != null && !houseno.isEmpty() && occupation != null) {
            if (!AddResidentMode1.isEmpIdEsxisting(id)) {
                if (AddResidentMode1.InsertResident(id, fname, mname, lname, houseno, street, barangay, city, prov, mstatus)) {
                    Alert.setText("Resident Added");
                    action.Exit(saveBtn);
                } else {
                    Alert.setText("Resident not Added");
                }
            } else {
                Alert.setText("Resident Id Already Taken");
            }
        } else {
            Alert.setText("Fill out the Necessary Information (*)");
        }
    }
}
