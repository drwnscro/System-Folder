package brgy_abella_system.Blotter;

public class Blotter {
    private String caseNo, empId, firstNameD, middleNameD, lastNameD, contactNoD, streetD, barangayD, cityD, provinceD
            , firstNameC, middleNameC, lastNameC, contactNoC, streetC, barangayC, cityC, provinceC
            , complaintDate, complaint, solution, fullNameC, fullNameD;
    
    public Blotter(String caseNo, String fullNameC, String fullNameD, String complaintDate) {
        this.caseNo = caseNo;
        this.fullNameC = fullNameC;
        this.fullNameD = fullNameD;
        this.complaintDate = complaintDate;
    }

    public String getCaseNo() {
        return caseNo;
    }

    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getFirstNameD() {
        return firstNameD;
    }

    public void setFirstNameD(String firstNameD) {
        this.firstNameD = firstNameD;
    }

    public String getMiddleNameD() {
        return middleNameD;
    }

    public void setMiddleNameD(String middleNameD) {
        this.middleNameD = middleNameD;
    }

    public String getLastNameD() {
        return lastNameD;
    }

    public void setLastNameD(String lastNameD) {
        this.lastNameD = lastNameD;
    }

    public String getContactNoD() {
        return contactNoD;
    }

    public void setContactNoD(String contactNoD) {
        this.contactNoD = contactNoD;
    }

    public String getStreetD() {
        return streetD;
    }

    public void setStreetD(String streetD) {
        this.streetD = streetD;
    }

    public String getBarangayD() {
        return barangayD;
    }

    public void setBarangayD(String barangayD) {
        this.barangayD = barangayD;
    }

    public String getCityD() {
        return cityD;
    }

    public void setCityD(String cityD) {
        this.cityD = cityD;
    }

    public String getProvinceD() {
        return provinceD;
    }

    public void setProvinceD(String provinceD) {
        this.provinceD = provinceD;
    }

    public String getFirstNameC() {
        return firstNameC;
    }

    public void setFirstNameC(String firstNameC) {
        this.firstNameC = firstNameC;
    }

    public String getMiddleNameC() {
        return middleNameC;
    }

    public void setMiddleNameC(String middleNameC) {
        this.middleNameC = middleNameC;
    }

    public String getLastNameC() {
        return lastNameC;
    }

    public void setLastNameC(String lastNameC) {
        this.lastNameC = lastNameC;
    }

    public String getContactNoC() {
        return contactNoC;
    }

    public void setContactNoC(String contactNoC) {
        this.contactNoC = contactNoC;
    }

    public String getStreetC() {
        return streetC;
    }

    public void setStreetC(String streetC) {
        this.streetC = streetC;
    }

    public String getBarangayC() {
        return barangayC;
    }

    public void setBarangayC(String barangayC) {
        this.barangayC = barangayC;
    }

    public String getCityC() {
        return cityC;
    }

    public void setCityC(String cityC) {
        this.cityC = cityC;
    }

    public String getProvinceC() {
        return provinceC;
    }

    public void setProvinceC(String provinceC) {
        this.provinceC = provinceC;
    }

    public String getComplaintDate() {
        return complaintDate;
    }

    public void setComplaintDate(String complaintDate) {
        this.complaintDate = complaintDate;
    }

    public String getComplaint() {
        return complaint;
    }

    public void setComplaint(String complaint) {
        this.complaint = complaint;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public String getFullNameC() {
        return fullNameC;
    }

    public void setFullNameC(String fullNameC) {
        this.fullNameC = fullNameC;
    }

    public String getFullNameD() {
        return fullNameD;
    }

    public void setFullNameD(String fullNameD) {
        this.fullNameD = fullNameD;
    }

    
    
}
